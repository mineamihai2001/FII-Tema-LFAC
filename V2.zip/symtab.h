//Cum am definit tipurile
//0 - bool
//1 - int
//2 - string
//3 - char
//4 - float
typedef struct expr_info
{
    int intvalue;
    char* strvalue;
    char charvalue;
    float floatvalue;
    int type;
} expr_info;

typedef struct symtab
{
    int valoare;
    char* nume;
}symtab;
