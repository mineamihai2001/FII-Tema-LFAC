typedef struct expr_info
{
    int intvalue;
    char* strvalue;
    int type;
} expr_info;

typedef struct symtab
{
    int valoare;
    char* nume;
}symtab;
